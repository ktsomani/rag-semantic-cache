# Microsoft Azure

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/Microsoft_Azure>*

Microsoft Azure, sometimes stylized Azure, and formerly Windows Azure, is the cloud computing platform developed by Microsoft. It offers management, access and development of applications and services to individuals, companies, and governments through its global infrastructure. Microsoft Azure supports multiple programming languages, tools, and frameworks, including Microsoft-specific and third-party software and systems.
Azure was first introduced at the Professional Developers Conference (PDC) in October 2008 under the code name "Project Red Dog". It was officially launched as Windows Azure in February 2010 and later renamed to Microsoft Azure on March 25, 2014.

##  Services 
Microsoft Azure uses large-scale virtualization at Microsoft data centers worldwide and offers more than 600 services. Microsoft Azure offers a service level agreement (SLA) that guarantees 99.9% availability for applications and data hosted on its platform, subject to specific terms and conditions outlined in the SLA documentation.

###  Computer services 
Virtual machines, infrastructure as a service (IaaS), allowing users to launch general-purpose Microsoft Windows and Linux virtual machines, software as a service (SaaS), as well as preconfigured machine images for popular software packages.
Starting in 2022, these virtual machines are now powered by Ampere Cloud-native processors.
Most users run Linux on Azure, some of the many Linux distributions offered, including Microsoft's own Linux-based Azure Sphere.
App services, a platform as a service (PaaS) environment for publishing and managing websites.
Azure Web Apps, formerly Azure Web Sites, allows developers to build and deploy websites using various programming languages and deployment tools. This PaaS feature was announced in June 2012 and renamed in April 2015.
Web Jobs are applications that can be deployed to an App Service environment to implement background processing that can be invoked on a schedule, on-demand, or run continuously. The Blob, Table, and Queue services can be used to communicate between Web Apps and Web Jobs and to provide state.
Azure Kubernetes Service (AKS) provides the capability to deploy production-ready Kubernetes clusters in Azure.
In July 2023, watermarking support on Azure Virtual Desktop was announced as an optional feature of Screen Capture to provide additional security against data leakage.

###  Identity 
Entra ID connect is used to synchronize on-premises directories and enable SSO (Single Sign On).
Entra ID B2C allows the use of consumer identity and access management in the cloud.
Entra Domain Services is used to join Azure virtual machines to a domain without domain controllers.
Azure information protection can be used to protect sensitive information.
Entra ID External Identities is a set of capabilities that allow organizations to collaborate with external users, including customers and partners.
On July 11, 2023, Microsoft announced the renaming of Azure AD to Microsoft Entra ID. The name change took place four days later.

###  Mobile services 
Mobile Engagement collects real-time analytics that highlight users' behavior. It also provides push notifications to mobile devices.
HockeyApp can be used to develop, distribute, and beta-test mobile apps.

###  Storage services 
Storage Services provides REST and SDK APIs for storing and accessing data on the cloud.
Table Service lets programs store structured text in partitioned collections of entities that are accessed by the partition key and primary key. Azure Table Service is a NoSQL non-relational database.
Blob Service allows programs to store unstructured text and binary data as object storage blobs that can be accessed by an HTTP(S) path. Blob service also provides security mechanisms to control access to data.
Queue Service lets programs communicate asynchronously by message using queues.
File Service allows storing and access of data on the cloud using the REST APIs or the SMB protocol.

###  Communication services 
Azure Communication Services offers an SDK for creating web and mobile communications applications that include SMS, video calling, VOIP and PSTN calling, and web-based chat.

###  Data management 
Azure Data Explorer provides big data analytics and data-exploration capabilities.
Azure Search provides text search and a subset of OData's structured filters using REST or SDK APIs.
Cosmos DB is a NoSQL database service that implements a subset of the SQL SELECT statement on JSON documents.
Azure Cache for Redis is a managed implementation of Redis.
StorSimple manages storage tasks between on-premises devices and cloud storage.
Azure SQL Database works to create, scale, and extend applications into the cloud using Microsoft SQL Server technology. It also integrates with Active Directory, Microsoft System Center, and Hadoop.
Azure Synapse Analytics is a fully managed cloud data warehouse.
Azure Data Factory is a data integration service that allows creation of data-driven workflows in the cloud for orchestrating and automating data movement and data transformation.
Azure Data Lake is a scalable data storage and analytic service for big data analytics workloads that require developers to run massively parallel queries.
Azure HDInsight is a big data-relevant service that deploys Hortonworks Hadoop on Microsoft Azure and supports the creation of Hadoop clusters using Linux with Ubuntu.
Azure Stream Analytics is a Serverless scalable event-processing engine that enables users to develop and run real-time analytics on multiple streams of data from sources such as devices, sensors, websites, social media, and other applications.

###  Messaging 
The Microsoft Azure Service Bus allows applications running on Azure premises or off-premises devices to communicate with Azure. This helps to build scalable and reliable applications in a service-oriented architecture (SOA). The Azure service bus supports four different types of communication mechanisms:

Event Hubs, which provides event and telemetry ingress to the cloud at a massive scale, with low latency and high reliability. For example, an event hub can be used to track data from cell phones such as coordinating with a GPS in real time.
Queues, which allows one-directional communication. A sender application would send the message to the service bus queue and a receiver would read from the queue. Though there can be multiple readers for the queue, only one would process a single message.
Topics, which provides one-directional communication using a subscriber pattern. It is similar to a queue; however, each subscriber will receive a copy of the message sent to a Topic. Optionally, the subscriber can filter out messages based on specific criteria defined by the subscriber.
Relays, which provides bi-directional communication. Unlike queues and topics, a relay does not store in-flight messages in its memory; instead, it just passes them on to the destination application.

###  Media services 
A PaaS offering that can be used for encoding, content protection, streaming, or analytics.

###  CDN 
Azure has a worldwide content delivery network (CDN) designed to efficiently deliver audio, video, applications, images, and other static files. It improves the performance of websites by caching static files closer to users, based on their geographic location. Users can manage the network using a REST-based HTTP API.
Azure has 118 point-of-presence locations across 100 cities worldwide (also known as Edge locations) as of January 2023.

###  Developer 
Application Insights
Azure DevOps

###  Management 
Azure Automation allows users to automate repetitive tasks using runbooks or desired state configurations for process automation.
Microsoft SMA

###  Azure AI 
Microsoft Azure Machine Learning (Azure ML) provides tools and frameworks for developers to create their own machine learning and artificial intelligence (AI) services.
Azure AI Services by Microsoft comprises prebuilt APIs, SDKs, and services developers can customize. These services encompass perceptual and cognitive intelligence features such as speech recognition, speaker recognition, neural speech synthesis, face recognition, computer vision, OCR/form understanding, natural language processing, machine translation, and business decision services. Many AI characteristics in Microsoft's products and services, namely Bing, Office, Teams, Xbox, and Windows, are driven by Azure AI Services.
Microsoft Foundry (formerly known as Azure AI Studio) can be used for building and deploying generative AI applications, notably using OpenAI's foundation model GPT-4o.

###  Azure Blockchain Workbench 
Through Azure Blockchain Workbench, Microsoft is providing the required infrastructure to set up a consortium network in multiple topologies using a variety of consensus mechanisms. Microsoft provides integration from these blockchain platforms to other Microsoft services to streamline the development of distributed applications. Microsoft supports many general-purpose blockchains, including Ethereum and Hyperledger Fabric and purpose-built blockchains like Corda.

###  Azure Function 
Azure functions are used in serverless computing architectures, where subscribers can execute code as an event-driven Function-as-a-Service (FaaS) without managing the underlying server resources. Customers using Azure functions are billed based on per-second resource consumption and executions.

###  Internet of Things (IoT) 
Azure IoT Hub enables the connection, monitoring, and management of a large number of IoT assets. On February 4, 2016, Microsoft announced the General Availability of the Azure IoT Hub service.
Azure IoT Edge is a fully managed service built on IoT Hub that allows for cloud intelligence deployed locally on IoT edge devices.
Azure IoT Central is a managed SaaS application for connecting, monitoring, and managing IoT assets. Its public preview was announced on December 5, 2017. On December 5, 2017, Microsoft announced the Public Preview of Azure IoT Central, its Azure IoT SaaS service.
On October 4, 2017, Microsoft began shipping GA versions of the official Microsoft Azure IoT Developer Kit (Devkit) board, manufactured by MX Chip.
On April 16, 2018, Microsoft announced the launch of the Azure Sphere, an end-to-end IoT product that focuses on microcontroller-based devices and uses Linux.
On May 7, 2018, Microsoft announced the launch of Azure Maps, an enterprise maps API and SDK platform.
On June 27, 2018, Microsoft launched Azure IoT Edge, used to run Azure services and artificial intelligence on IoT devices.
On November 20, 2018, Microsoft launched the Open Enclave SDK for cross-platform systems such as ARM Trust Zone and Intel SGX.

###  Azure Local 
Azure Local (previously Azure Stack HCI) is a hyper-converged infrastructure (HCI) product that uses validated hardware to run virtualized workloads on-premises to consolidate aging infrastructure and connect to Azure for cloud services.

###  Azure Orbital 
Launched in September 2020, Azure Orbital lets private industries and government agencies process satellite data quickly by connecting directly to cloud computing networks. Mobile cloud computing ground stations are also available to provide connectivity to remote locations without ground infrastructure. Third-party satellite systems, like SpaceX's Starlink and SES' O3b constellation, can be employed.
SES plans to use Microsoft's data centers to provide cloud connectivity to remote areas through its next generation O3b mPOWER MEO satellites alongside Microsoft's data centers. The company will deploy satellite control and uplink ground stations to achieve this. SES launched the first two O3b mPOWER satellites in December 2022; nine more are scheduled between 2023 and 2024. The service should begin in Q3 2023.
According to Microsoft, satellite cloud connectivity can provide lower latency than terrestrial fiber routes in specific regions. The company stated that during network testing for Xbox Cloud, satellite connections out-performed terrestrial networks in certain rural or geographically remote areas of the United States due to fewer network routing hops.
Azure Orbital was retired in December 2024, with existing assets being sold off to Space Leasing International.

###  Azure Container Storage 
In August 2024, Azure launched Azure Container Storage, a platform-managed container-native storage service for the public cloud. The service supports Ephemeral Disks (Local NVMe/Temp SSD) and Azure Disks for containerized applications.

###  Azure Quantum 
Released for public preview in 2021. Azure Quantum provides access to quantum hardware and software. The platform provides access to third-party quantum systems utilizing varied hardware architectures, including trapped ion, neutral atom, and superconducting systems.
Azure Quantum Elements is an integrated cloud software platform designed for computational chemistry and materials science applications that uses artificial intelligence models, high-performance computing clusters, and cloud-based quantum processor access to execute molecular simulations.The platform includes a GPT-4-based tool called Copilot to assist users in querying dataset metrics, generating code scripts, and setting up simulations.
In 2021, Microsoft developed the quantum programming language Q# (pronounced Q Sharp) and an open-source quantum development kit for algorithm development and simulation.
In 2023, Microsoft developed Quantum Intermediate Representation (QIR) from LLVM as a common interface between programming languages and target quantum processors.
The Azure Quantum Resource Estimator estimates the resources required to execute a given quantum algorithm on a fault-tolerant quantum computer. It can also show how future quantum computers will impact today's encryption algorithms.

##  Regional expansion 
As of 2018, Azure was available in 54 regions, and Microsoft was the first primary cloud provider to establish facilities in Africa, with two regions in South Africa. Azure geographies consist of multiple Azure Regions, like "North Europe" (located in Dublin, Ireland) and "West Europe" (located in Amsterdam, Netherlands).
On June 19, 2019, Microsoft announced the launch of two new cloud regions in the United Arab Emirates – Microsoft's first in the Middle East. On March 6, 2025, the company announced a strategic partnership with the Government of Kuwait, represented by the Central Agency for Information Technology (CAIT) and the Communication and Information Technology Regulatory Authority (CITRA). This collaboration aims to accelerate digital transformation efforts aligned with Kuwait's Vision 2035. The partnership will focus on creating an AI-powered Azure Region to enhance local AI capabilities, stimulate economic growth, and drive innovation across various industries.

##  Research partnerships 
In August 2018, Toyota Tsusho collaborated with Microsoft to deploy an aquaculture water management system using Azure IoT and machine learning applications. Developed alongside researchers from Kindai University, the system uses computer vision on water pump conveyor belts to log fish counts, monitor stock quantities, and track automated water flow metrics via the Azure Machine Learning and Azure IoT Hub services.

##  Design 
Microsoft Azure utilizes a specialized operating system with the same name to power its "fabric layer". This cluster is hosted at Microsoft's data centers and is responsible for managing computing and storage resources and allocating them to applications running on the Microsoft Azure platform. It is a "cloud layer" built upon various Windows Server systems, including the customized Microsoft Azure Hypervisor, which is based on Windows Server 2008 and enables the virtualization of services.
The Microsoft Azure Fabric Controller maintains the scalability and dependability of services and environments in the data center. It prevents failure in server malfunction and manages users' web applications, including memory allocation and load balancing.
Azure provides an API built on REST, HTTP, and XML that allows a developer to interact with the services offered by Microsoft Azure. Microsoft also provides a client-side managed class library that encapsulates the functions of interacting with the services. It also integrates with Microsoft Visual Studio, Git, and Eclipse.
Users can manage Azure services in multiple ways, one of which is through the Web-based Azure Portal, which became generally available in December 2015. Apart from accessing services via API, users can browse active resources, adjust settings, launch new resources, and view primary monitoring data of functional virtual machines and services using the portal.

###  Deployment models 
Regarding cloud resources, Microsoft Azure offers two deployment models: the "classic" model and the Azure Resource Manager. In the classic model, each resource, like a virtual machine or SQL database, had to be managed separately, but in 2014, Azure introduced the Azure Resource Manager, which allows users to group related services. This update makes it easier and more efficient to deploy, manage, and monitor resources that work closely together. The classic model will eventually be phased out.

###  Infrastructure development 
In January 2025, Microsoft announced plans to invest $80 billion in AI and data centers as part of its fiscal year 2025 budget. This investment would enhance the scalability and performance of Azure's cloud infrastructure, which supports AI-driven applications, including services developed through Microsoft's partnership with OpenAI.

##  History and timeline 
In 2005, Microsoft took over Groove Networks, and Bill Gates made Groove's founder Ray Ozzie one of his 5 direct reports as one of 3 chief technology officers. Ozzie met with Amitabh Srivastava, which let Srivastava change course. They convinced Dave Cutler to postpone his retirement, and their teams developed a cloud operating system.

October 2008 (PDC LA) – Announced the Windows Azure Platform.
March 2009 – Announced SQL Azure Relational Database.
November 2009 – Updated Windows Azure CTP, Enabled full trust, PHP, Java, CDN CTP, and more.
February 1, 2010 – Windows Azure Platform commercially available.
June 2010 – Windows Azure Update, .NET Framework 4, OS Versioning, CDN, SQL Azure Update.
October 2010 (PDC) – Platform enhancements, Windows Azure Connect, improved Dev / IT Pro Experience.
December 2011 – Traffic manager, SQL Azure reporting, HPC scheduler.
June 2012 – Websites, Virtual machines for Windows and Linux, Python SDK, new portal, locally redundant storage.
April 2014 – Windows Azure renamed Microsoft Azure, ARM Portal introduced at Build 2014.
July 2014 – Azure Machine Learning public preview.
November 2014 – Outage affecting major websites, including MSN.com.
September 2015 – Azure Cloud Switch introduced as a cross-platform Linux distribution. Currently known as SONiC.
December 2015 – Azure ARM Portal (codename "Ibiza") released.
March 2016 – Azure Service Fabric is generally available.
November 15, 2016 – Azure Functions is generally available.
May 10, 2017 – Azure Cosmos DB is generally available.
May 7, 2018 – Azure Maps is generally available.
July 16, 2018 – Azure Service Fabric Mesh public preview.
September 24, 2018 – Microsoft Azure IoT Central is generally available.
October 10, 2018 – Microsoft joins the Linux-oriented group Open Invention Network.
April 17, 2019 – Azure Front Door Service is now available.
March 2020 – Microsoft said that there was a 775% increase in Microsoft Teams usage in Italy due to the COVID-19 pandemic. The company estimates there are now 44 million daily active users of Teams worldwide.
January 17, 2023 – Azure OpenAI Service is generally available.
At fiscal year-end 2025, Microsoft reported that Azure surpassed US$75 billion in annual revenue and operated over 400 datacenters across 70 regions.

##  Privacy 
According to the Patriot Act, Microsoft has acknowledged that the U.S. government can access data even if the hosting company is not American and the data is outside the U.S. To address concerns related to privacy and security, Microsoft has established the Microsoft Azure Trust Center. Microsoft Azure offers services that comply with multiple compliance programs, including ISO 27001:2005 and HIPAA. A comprehensive and up-to-date list of these services is available on the Microsoft Azure Trust Center Compliance page. Microsoft Azure received JAB Provisional Authority to Operate (P-ATO) from the U.S. government under the Federal Risk and Authorization Management Program (FedRAMP) guidelines. This program provides a standardized approach to security assessment, authorization, and continuous monitoring for cloud services used by the federal government.

##  Human rights campaigns 
In 2025, an activist campaign named "No Azure for Apartheid" accused Microsoft of providing cloud and AI services to entities involved in Israeli policies within the Palestinian territories. Campaign organizers argue that Azure's technology could enable surveillance and displacement, drawing parallels to historical corporate involvement in apartheid regimes. Similar activism has targeted other technology companies, such as the No Tech for Apartheid movement directed at Google and Amazon, though critics state that Microsoft's specific government contracts and military partnerships draw heightened scrutiny. Protesters have demanded transparency, ethical oversight, and the termination of contracts that they state facilitate human rights violations. Microsoft has stated that its operations comply with international laws and regulations.

##  Significant outages 
The following is a list of Microsoft Azure outages and service disruptions.

##  Certifications 
A large variety of Azure certifications can be attained, each requiring one or multiple successfully completed examinations. Certification levels range from beginner, intermediate to expert.
Examples of common certifications include:

Azure Fundamentals
Azure Data Fundamentals
Azure AI Engineer Associate
Azure AI Fundamentals
Azure Cosmos DB Developer Specialty
Azure Administrator Associate
Azure Data Engineer Associate
Azure Data Scientist Associate
Azure Database Administrator Associate
Azure Developer Associate
Azure Enterprise Data Analyst Associate
Azure Security Engineer Associate
Azure Security Operations Analyst Associate
Azure Identity and Access Administrator Associate
Azure Security, Compliance, and Identity Fundamentals
Azure Network Engineer Associate
Azure Windows Server Hybrid Administrator Associate
Azure Virtual Desktop Specialty
Azure for SAP Workloads Specialty
Azure Customer Data Platform Specialty
Azure Cybersecurity Architect Expert
Azure Solutions Architect Expert
Azure Power Platform Solution Architect Expert
Azure DevOps Engineer Expert
Azure IoT Developer Specialty
Azure Stack Hub Operator Associate
Azure Machine Learning Specialty

##  Key people 
Dave Cutler, Lead Developer, Microsoft Azure
Mark Russinovich, CTO, Microsoft Azure
Scott Guthrie, Executive Vice President of the Cloud and AI group in Microsoft
Jason Zander, Executive Vice President, Microsoft Azure
Julia White, Corporate Vice President, Microsoft Azure

##  Issues 
Microsoft Azure's services can have varied and complex pricing models. Technical writers have noted that the Azure Portal layout can cause slow navigation and user error if complex configurations are mismanaged.n

###  Security 
In August 2021, researchers from Wiz Research claimed to have discovered a vulnerability in the Azure Cosmos DB database, referred to as "ChaosDB." They claimed that they had gained complete unrestricted access to the accounts and databases of several thousand Microsoft Azure customers. In August 2021, Microsoft claimed they mitigated the vulnerability and no customer data was accessed.
In September 2021, researchers from Palo Alto Networks claimed to discover a significant cross-account takeover vulnerability in Azure Container Instances, named "Azurescape". According to Palo Alto Networks' researchers, this vulnerability is the first known instance that allows one user of a public cloud service to escape their environment and execute code on other users' environments within the same service. Although Microsoft quickly patched the issue, Palo Alto Networks advised Azure customers to revoke any privileged credentials deployed before August 31, 2021, as a precaution. In September 2021, Microsoft claimed they fixed the vulnerability.
In September 2021, researchers from Wiz Research claimed they found four critical vulnerabilities in the Open Management Infrastructure (OMI), which is Azure's software agent deployed on a large portion of Linux VMs in Azure. The researchers named it "OMIGOD" and claimed that these vulnerabilities allowed for remote code execution within the Azure network and could escalate privileges to root. They claimed that the vulnerabilities affected various Azure services, including Azure Log Analytics, Azure Diagnostics, and Azure Security Center. In response, Microsoft announced that it had released fixes for the aforementioned vulnerabilities in September 2021.
In July 2023, U.S. Senator Ron Wyden called on the Cybersecurity and Infrastructure Security Agency (CISA), the Justice Department, and the Federal Trade Commission to hold Microsoft accountable for what he described as "negligent cybersecurity practices." This came in the wake of an alleged cyberattack orchestrated by Chinese hackers, who exploited a vulnerability in Microsoft's software to compromise U.S. government email systems. Similarly, Amit Yoran, the CEO of cybersecurity firm Tenable, Inc., criticized Microsoft's security practices, describing them as "grossly irresponsible" and accusing the company of a "culture of toxic obfuscation." The Cyber Safety Review Board produced a report attributing the success of the intrusion to a cascade of security failures by Microsoft, describing the company's internal security culture as inadequate.

##  See also 
Cloud-computing comparison
Comparison of file hosting services
Microsoft Azure Dev Tools for Teaching
Azure Linux

##  Notes 
##  References 
###  Citations 
###  Sources 
##  Further reading 
##  External links 
Official website
